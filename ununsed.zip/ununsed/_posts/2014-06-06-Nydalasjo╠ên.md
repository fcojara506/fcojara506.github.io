---
date: 2013-06-07
layout: redirect
slug: 
title: "Nydalasjön"
categories:
- outdoors
tag:
- outdoors 
- Sweden
- National Day
- bog
external_url: http://elza.me/blog/2013/06/Nydalasj%C3%B6n/
---