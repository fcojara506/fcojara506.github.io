{
  const script = document.createElement("script");
  script.src = "https://assets.gumroad.com/packs/js/overlay-70efe6de0c91f5af7dbd.js";
  script.charset = "utf-8";
  document.head.appendChild(script);
    document.head.innerHTML += '<link rel="stylesheet" href="https://assets.gumroad.com/packs/css/overlay-7e442b20.css" media="screen" />';

    const loaderScript = document.querySelector("script[src*='/js/gumroad.js']");
    loaderScript.dataset.stylesUrl = "https://assets.gumroad.com/packs/css/design-d2e95d33.css";
}
